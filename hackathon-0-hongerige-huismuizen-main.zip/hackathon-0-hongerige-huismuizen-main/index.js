btn = document.getElementById("bestBtn");
btn.addEventListener("click", function (event) {
    event.preventDefault()
    window.location.href = 'https://www.thisworldthesedays.com/the-best-button-tutorial.html';
});